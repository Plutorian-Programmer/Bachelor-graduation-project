The file *Uva-bachelor-thesis.tex*  is required to be used as  front pages for the BSc Kunstmatige Intelligentie thesis.
The fields commented with _CHANGE_ need to be adapted for your thesis.

The file _uva\_logo.png_ is required.

The file _augmented-intelligence.jpeg_ is preferably changed to an image relevant for your thesis topic (see comments in the .tex-file).  